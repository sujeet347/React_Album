export const NoConversation = () => {
    return (
        <div className="NoConsevation">
        <h1>No Conservation Started yet.</h1>
        <h3>Let's chat...</h3>
        </div>
    )
}