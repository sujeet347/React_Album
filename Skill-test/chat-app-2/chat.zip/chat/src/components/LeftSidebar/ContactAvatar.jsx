export const ContactAvatar = ({image}) => {
    return (
        <div>
            <img src={image} alt="userAvatar" className="avatar"/>
        </div>
    )
}