import userImg from "../images/user.jpg"
export default function user(state = {}) {
    return{
        id: 1,
        name: "Abhijeet kumar",
        image: userImg
    }
}